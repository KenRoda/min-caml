let x = 1 in
let y = 3 in
let a = x + y in
let b = x + y in
let c = (let d = 11 in d) in
print_int (a+b)
