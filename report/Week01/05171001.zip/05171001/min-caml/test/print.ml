print_int 123;
print_int (-456);
print_int (789+0)
