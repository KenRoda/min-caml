let x = 1 in
let y = 3 in
let a = x + y in
let b = x + y in
print_int (a+b)
